-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2025 at 10:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_jasa_loundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `berita`
--

CREATE TABLE `berita` (
  `id_berita` varchar(20) NOT NULL,
  `id_kategori` varchar(20) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `judul_seo` varchar(255) DEFAULT NULL,
  `headline` varchar(20) DEFAULT NULL,
  `isi_berita` varchar(2000) DEFAULT NULL,
  `hari` varchar(20) DEFAULT NULL,
  `tanggal` varchar(50) DEFAULT NULL,
  `jam` varchar(50) DEFAULT NULL,
  `dibaca` varchar(20) DEFAULT NULL,
  `tag` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kategori_berita`
--

CREATE TABLE `kategori_berita` (
  `id_kategori` varchar(20) NOT NULL,
  `nama_kategori` varchar(100) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ongkos`
--

CREATE TABLE `ongkos` (
  `id_ongkos` varchar(20) NOT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `ongkos` varchar(20) DEFAULT NULL,
  `aktif` varchar(20) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pesan`
--

CREATE TABLE `pesan` (
  `no_pesan` varchar(20) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `ongkos` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `biaya_laundry` varchar(20) DEFAULT NULL,
  `total_bayar` varchar(20) DEFAULT NULL,
  `tanggal` varchar(50) DEFAULT NULL,
  `berat` varchar(20) DEFAULT NULL,
  `harga_parfum` varchar(20) DEFAULT NULL,
  `aksi` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `berita`
--
ALTER TABLE `berita`
  ADD PRIMARY KEY (`id_berita`);

--
-- Indexes for table `kategori_berita`
--
ALTER TABLE `kategori_berita`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `ongkos`
--
ALTER TABLE `ongkos`
  ADD PRIMARY KEY (`id_ongkos`);

--
-- Indexes for table `pesan`
--
ALTER TABLE `pesan`
  ADD PRIMARY KEY (`no_pesan`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

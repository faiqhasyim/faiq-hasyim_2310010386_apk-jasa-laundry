/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package apkjasafaiq;
import form.FrameApp;

/**
 *
 * @author User
 */
public class ApkJasaFaiq {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FrameApp frame = new FrameApp();
        frame.setVisible(true);
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package crud;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.JTable;
import java.sql.ResultSetMetaData;
/**
 *
 * @author User
 */
    public class crud {
    private Connection Koneksidb;
    private String username="root";
    private String password="";
    private String dbname="db_jasa_loundry"; 
    private String urlKoneksi="jdbc:mysql://localhost/"+dbname;
    public boolean duplikasi=false;

    public String CEK_ID_KATEGORI_B, CEK_USERNAME_B, CEK_JUDUL_B, CEK_JUDUL_SEO_B, CEK_HEADLINE_B, CEK_ISI_BERITA_B, CEK_HARI_B, CEK_TANGGAL_B, CEK_JAM_B, CEK_DIBACA_B, CEK_TAG_B = null;
    public String CEK_ALAMAT_O, CEK_ONGKOS_O, CEK_AKTIF_O, CEK_KELURAHAN_O = null;
    public String CEK_NAMA_P, CEK_ALAMAT_P, CEK_KELURAHAN_P, CEK_KECAMATAN_P, CEK_ONGKOS_P, CEK_STATUS_P, CEK_BIAYA_LAUNDRY_P, CEK_TOTAL_BAYAR_P, CEK_TANGGAL_P, CEK_BERAT_P, CEK_HARGA_PARFUM_P, CEK_AKSI_P = null;
    public String CEK_NAMA_KATEGORI_KB, CEK_KETERANGAN_KB = null;

    
    public crud(){
        try {
            Driver dbdriver = new com.mysql.jdbc.Driver();
            DriverManager.registerDriver(dbdriver);
            Koneksidb=DriverManager.getConnection(urlKoneksi,username,password);
            System.out.print("Database Terkoneksi");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e.toString());
        }
    }

    public void simpanBerita01(String id_berita, String id_kategori, String username, String judul, String judul_seo, String headline, String isi_berita, String hari, String tanggal, String jam, String dibaca, String tag){
        try {
            String sqlsimpan="insert into berita(id_berita, id_kategori, username, judul, judul_seo, headline, isi_berita, hari, tanggal, jam, dibaca, tag) value"
                    + " ('"+id_berita+"', '"+id_kategori+"', '"+username+"', '"+judul+"', '"+judul_seo+"', '"+headline+"', '"+isi_berita+"', '"+hari+"', '"+tanggal+"', '"+jam+"', '"+dibaca+"', '"+tag+"')";
            String sqlcari="select*from berita where id_berita='"+id_berita+"'";
            
            Statement cari=Koneksidb.createStatement();
            ResultSet data=cari.executeQuery(sqlcari);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Berita sudah terdaftar");
            } else {
                Statement perintah=Koneksidb.createStatement();
                perintah.execute(sqlsimpan);
                JOptionPane.showMessageDialog(null, "Data Berita berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void simpanBerita02(String id_berita, String id_kategori, String username, String judul, String judul_seo, String headline, String isi_berita, String hari, String tanggal, String jam, String dibaca, String tag){
        try {
            // Kolom 'gambar' DIHILANGKAN
            String sqlsimpan="INSERT INTO berita (id_berita, id_kategori, username, judul, judul_seo, headline, isi_berita, hari, tanggal, jam, dibaca, tag) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            String sqlcari= "SELECT*FROM berita WHERE id_berita = ?";
            
            PreparedStatement cari = Koneksidb.prepareStatement(sqlcari);
            cari.setString(1, id_berita);
            ResultSet data = cari.executeQuery();
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Berita sudah terdaftar");
                this.duplikasi = true;
                this.CEK_ID_KATEGORI_B = data.getString("id_kategori");
                this.CEK_USERNAME_B = data.getString("username");
                this.CEK_JUDUL_B = data.getString("judul");
                this.CEK_JUDUL_SEO_B = data.getString("judul_seo");
                this.CEK_HEADLINE_B = data.getString("headline");
                this.CEK_ISI_BERITA_B = data.getString("isi_berita");
                this.CEK_HARI_B = data.getString("hari");
                this.CEK_TANGGAL_B = data.getString("tanggal");
                this.CEK_JAM_B = data.getString("jam");
                this.CEK_DIBACA_B = data.getString("dibaca");
                this.CEK_TAG_B = data.getString("tag");
            } else {
                this.duplikasi = false;
                this.CEK_ID_KATEGORI_B = null;
                this.CEK_USERNAME_B = null;
                this.CEK_JUDUL_B = null;
                this.CEK_JUDUL_SEO_B = null;
                this.CEK_HEADLINE_B = null;
                this.CEK_ISI_BERITA_B = null;
                this.CEK_HARI_B = null;
                this.CEK_TANGGAL_B = null;
                this.CEK_JAM_B = null;
                this.CEK_DIBACA_B = null;
                this.CEK_TAG_B = null;
                
                PreparedStatement perintah = Koneksidb.prepareStatement(sqlsimpan);
                perintah.setString(1, id_berita);
                perintah.setString(2, id_kategori);
                perintah.setString(3, username);
                perintah.setString(4, judul);
                perintah.setString(5, judul_seo);
                perintah.setString(6, headline);
                perintah.setString(7, isi_berita);
                perintah.setString(8, hari);
                perintah.setString(9, tanggal);
                perintah.setString(10, jam);
                perintah.setString(11, dibaca);
                perintah.setString(12, tag);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Berita berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahBerita(String id_berita, String id_kategori, String username, String judul, String judul_seo, String headline, String isi_berita, String hari, String tanggal, String jam, String dibaca, String tag){
        try {
            String sqlubah="UPDATE berita SET id_kategori = ?, username = ?, judul = ?, judul_seo = ?, headline = ?, isi_berita = ?, hari = ?, tanggal = ?, jam = ?, dibaca = ?, tag = ? WHERE id_berita = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlubah);
            perintah.setString(1, id_kategori);
            perintah.setString(2, username);
            perintah.setString(3, judul);
            perintah.setString(4, judul_seo);
            perintah.setString(5, headline);
            perintah.setString(6, isi_berita);
            perintah.setString(7, hari);
            perintah.setString(8, tanggal);
            perintah.setString(9, jam);
            perintah.setString(10, dibaca);
            perintah.setString(11, tag);
            perintah.setString(12, id_berita); 
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berita berhasil diubah");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusBerita(String id_berita){
        try {
            String sqlhapus="DELETE FROM berita WHERE id_berita = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlhapus);
            perintah.setString(1, id_berita);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Berita berhasil dihapus");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataBerita(JTable komponentabel, String SQL){
        try {
            PreparedStatement perintah = Koneksidb.prepareStatement(SQL);
            ResultSet data = perintah.executeQuery();
            ResultSetMetaData meta = data.getMetaData();
            int jumlahkolom = meta.getColumnCount();
            DefaultTableModel modeltabel = new DefaultTableModel();
            
            modeltabel.addColumn("ID Berita");
            modeltabel.addColumn("ID Kategori");
            modeltabel.addColumn("Username");
            modeltabel.addColumn("Judul");
            modeltabel.addColumn("Judul SEO");
            modeltabel.addColumn("Headline");
            modeltabel.addColumn("Isi Berita");
            modeltabel.addColumn("Hari");
            modeltabel.addColumn("Tanggal");
            modeltabel.addColumn("Jam");
            modeltabel.addColumn("Dibaca");
            modeltabel.addColumn("Tag");
            
            while(data.next()){
                Object[] row = new Object[jumlahkolom];
                for(int i=1; i<=jumlahkolom; i++){
                    row[i-1]=data.getObject(i);
                }
                modeltabel.addRow(row);
            }
            komponentabel.setModel(modeltabel);
        } catch (Exception e) {
        }
    }

    public void simpanOngkos01(String id_ongkos, String alamat, String ongkos, String aktif, String kelurahan){
        try {
            String sqlsimpan="insert into ongkos(id_ongkos, alamat, ongkos, aktif, kelurahan) value"
                    + " ('"+id_ongkos+"', '"+alamat+"', '"+ongkos+"', '"+aktif+"', '"+kelurahan+"')";
            String sqlcari="select*from ongkos where id_ongkos='"+id_ongkos+"'";
            
            Statement cari=Koneksidb.createStatement();
            ResultSet data=cari.executeQuery(sqlcari);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Ongkos sudah terdaftar");
            } else {
                Statement perintah=Koneksidb.createStatement();
                perintah.execute(sqlsimpan);
                JOptionPane.showMessageDialog(null, "Data Ongkos berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void simpanOngkos02(String id_ongkos, String alamat, String ongkos, String aktif, String kelurahan){
        try {
            String sqlsimpan="INSERT INTO ongkos (id_ongkos, alamat, ongkos, aktif, kelurahan) VALUES (?, ?, ?, ?, ?)";
            String sqlcari= "SELECT*FROM ongkos WHERE id_ongkos = ?";
            
            PreparedStatement cari = Koneksidb.prepareStatement(sqlcari);
            cari.setString(1, id_ongkos);
            ResultSet data = cari.executeQuery();
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Ongkos sudah terdaftar");
                this.duplikasi = true;
                this.CEK_ALAMAT_O = data.getString("alamat");
                this.CEK_ONGKOS_O = data.getString("ongkos");
                this.CEK_AKTIF_O = data.getString("aktif");
                this.CEK_KELURAHAN_O = data.getString("kelurahan");
            } else {
                this.duplikasi = false;
                this.CEK_ALAMAT_O = null;
                this.CEK_ONGKOS_O = null;
                this.CEK_AKTIF_O = null;
                this.CEK_KELURAHAN_O = null;
                
                PreparedStatement perintah = Koneksidb.prepareStatement(sqlsimpan);
                perintah.setString(1, id_ongkos);
                perintah.setString(2, alamat);
                perintah.setString(3, ongkos);
                perintah.setString(4, aktif);
                perintah.setString(5, kelurahan);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Ongkos berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahOngkos(String id_ongkos, String alamat, String ongkos, String aktif, String kelurahan){
        try {
            String sqlubah="UPDATE ongkos SET alamat = ?, ongkos = ?, aktif = ?, kelurahan = ? WHERE id_ongkos = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlubah);
            perintah.setString(1, alamat);
            perintah.setString(2, ongkos);
            perintah.setString(3, aktif);
            perintah.setString(4, kelurahan);
            perintah.setString(5, id_ongkos); 
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Ongkos berhasil diubah");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusOngkos(String id_ongkos){
        try {
            String sqlhapus="DELETE FROM ongkos WHERE id_ongkos = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlhapus);
            perintah.setString(1, id_ongkos);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Ongkos berhasil dihapus");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataOngkos(JTable komponentabel, String SQL){
        try {
            PreparedStatement perintah = Koneksidb.prepareStatement(SQL);
            ResultSet data = perintah.executeQuery();
            ResultSetMetaData meta = data.getMetaData();
            int jumlahkolom = meta.getColumnCount();
            DefaultTableModel modeltabel = new DefaultTableModel();
            
            modeltabel.addColumn("ID Ongkos");
            modeltabel.addColumn("Alamat");
            modeltabel.addColumn("Ongkos");
            modeltabel.addColumn("Aktif");
            modeltabel.addColumn("Kelurahan");
            
            while(data.next()){
                Object[] row = new Object[jumlahkolom];
                for(int i=1; i<=jumlahkolom; i++){
                    row[i-1]=data.getObject(i);
                }
                modeltabel.addRow(row);
            }
            komponentabel.setModel(modeltabel);
        } catch (Exception e) {
        }
    }

    public void simpanPesan01(String no_pesan, String nama, String alamat, String kelurahan, String kecamatan, String ongkos, String status, String biaya_laundry, String total_bayar, String tanggal, String berat, String harga_parfum, String aksi){
        try {
            String sqlsimpan="insert into pesan(no_pesan, nama, alamat, kelurahan, kecamatan, ongkos, status, biaya_laundry, total_bayar, tanggal, berat, harga_parfum, aksi) value"
                    + " ('"+no_pesan+"', '"+nama+"', '"+alamat+"', '"+kelurahan+"', '"+kecamatan+"', '"+ongkos+"', '"+status+"', '"+biaya_laundry+"', '"+total_bayar+"', '"+tanggal+"', '"+berat+"', '"+harga_parfum+"', '"+aksi+"')";
            String sqlcari="select*from pesan where no_pesan='"+no_pesan+"'";
            
            Statement cari=Koneksidb.createStatement();
            ResultSet data=cari.executeQuery(sqlcari);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "No Pesan sudah terdaftar");
            } else {
                Statement perintah=Koneksidb.createStatement();
                perintah.execute(sqlsimpan);
                JOptionPane.showMessageDialog(null, "Data Pesan berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void simpanPesan02(String no_pesan, String nama, String alamat, String kelurahan, String kecamatan, String ongkos, String status, String biaya_laundry, String total_bayar, String tanggal, String berat, String harga_parfum, String aksi){
        try {
            String sqlsimpan="INSERT INTO pesan (no_pesan, nama, alamat, kelurahan, kecamatan, ongkos, status, biaya_laundry, total_bayar, tanggal, berat, harga_parfum, aksi) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            String sqlcari= "SELECT*FROM pesan WHERE no_pesan = ?";
            
            PreparedStatement cari = Koneksidb.prepareStatement(sqlcari);
            cari.setString(1, no_pesan);
            ResultSet data = cari.executeQuery();
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "No Pesan sudah terdaftar");
                this.duplikasi = true;
                this.CEK_NAMA_P = data.getString("nama");
                this.CEK_ALAMAT_P = data.getString("alamat");
                this.CEK_KELURAHAN_P = data.getString("kelurahan");
                this.CEK_KECAMATAN_P = data.getString("kecamatan");
                this.CEK_ONGKOS_P = data.getString("ongkos");
                this.CEK_STATUS_P = data.getString("status");
                this.CEK_BIAYA_LAUNDRY_P = data.getString("biaya_laundry");
                this.CEK_TOTAL_BAYAR_P = data.getString("total_bayar");
                this.CEK_TANGGAL_P = data.getString("tanggal");
                this.CEK_BERAT_P = data.getString("berat");
                this.CEK_HARGA_PARFUM_P = data.getString("harga_parfum");
                this.CEK_AKSI_P = data.getString("aksi");
            } else {
                this.duplikasi = false;
                this.CEK_NAMA_P = null;
                this.CEK_ALAMAT_P = null;
                this.CEK_KELURAHAN_P = null;
                this.CEK_KECAMATAN_P = null;
                this.CEK_ONGKOS_P = null;
                this.CEK_STATUS_P = null;
                this.CEK_BIAYA_LAUNDRY_P = null;
                this.CEK_TOTAL_BAYAR_P = null;
                this.CEK_TANGGAL_P = null;
                this.CEK_BERAT_P = null;
                this.CEK_HARGA_PARFUM_P = null;
                this.CEK_AKSI_P = null;
                
                PreparedStatement perintah = Koneksidb.prepareStatement(sqlsimpan);
                perintah.setString(1, no_pesan);
                perintah.setString(2, nama);
                perintah.setString(3, alamat);
                perintah.setString(4, kelurahan);
                perintah.setString(5, kecamatan);
                perintah.setString(6, ongkos);
                perintah.setString(7, status);
                perintah.setString(8, biaya_laundry);
                perintah.setString(9, total_bayar);
                perintah.setString(10, tanggal);
                perintah.setString(11, berat);
                perintah.setString(12, harga_parfum);
                perintah.setString(13, aksi);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Pesan berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahPesan(String no_pesan, String nama, String alamat, String kelurahan, String kecamatan, String ongkos, String status, String biaya_laundry, String total_bayar, String tanggal, String berat, String harga_parfum, String aksi){
        try {
            String sqlubah="UPDATE pesan SET nama = ?, alamat = ?, kelurahan = ?, kecamatan = ?, ongkos = ?, status = ?, biaya_laundry = ?, total_bayar = ?, tanggal = ?, berat = ?, harga_parfum = ?, aksi = ? WHERE no_pesan = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlubah);
            perintah.setString(1, nama);
            perintah.setString(2, alamat);
            perintah.setString(3, kelurahan);
            perintah.setString(4, kecamatan);
            perintah.setString(5, ongkos);
            perintah.setString(6, status);
            perintah.setString(7, biaya_laundry);
            perintah.setString(8, total_bayar);
            perintah.setString(9, tanggal);
            perintah.setString(10, berat);
            perintah.setString(11, harga_parfum);
            perintah.setString(12, aksi);
            perintah.setString(13, no_pesan); 
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Pesan berhasil diubah");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusPesan(String no_pesan){
        try {
            String sqlhapus="DELETE FROM pesan WHERE no_pesan = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlhapus);
            perintah.setString(1, no_pesan);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Pesan berhasil dihapus");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataPesan(JTable komponentabel, String SQL){
        try {
            PreparedStatement perintah = Koneksidb.prepareStatement(SQL);
            ResultSet data = perintah.executeQuery();
            ResultSetMetaData meta = data.getMetaData();
            int jumlahkolom = meta.getColumnCount();
            DefaultTableModel modeltabel = new DefaultTableModel();
            
            modeltabel.addColumn("No Pesan");
            modeltabel.addColumn("Nama");
            modeltabel.addColumn("Alamat");
            modeltabel.addColumn("Kelurahan");
            modeltabel.addColumn("Kecamatan");
            modeltabel.addColumn("Ongkos");
            modeltabel.addColumn("Status");
            modeltabel.addColumn("Biaya Laundry");
            modeltabel.addColumn("Total Bayar");
            modeltabel.addColumn("Tanggal");
            modeltabel.addColumn("Berat");
            modeltabel.addColumn("Harga Parfum");
            modeltabel.addColumn("Aksi");
            
            while(data.next()){
                Object[] row = new Object[jumlahkolom];
                for(int i=1; i<=jumlahkolom; i++){
                    row[i-1]=data.getObject(i);
                }
                modeltabel.addRow(row);
            }
            komponentabel.setModel(modeltabel);
        } catch (Exception e) {
        }
    }

    public void simpanKategoriBerita01(String id_kategori, String nama_kategori, String keterangan){
        try {
            String sqlsimpan="insert into kategori_berita(id_kategori, nama_kategori, keterangan) value"
                    + " ('"+id_kategori+"', '"+nama_kategori+"', '"+keterangan+"')";
            String sqlcari="select*from kategori_berita where id_kategori='"+id_kategori+"'";
            
            Statement cari=Koneksidb.createStatement();
            ResultSet data=cari.executeQuery(sqlcari);
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Kategori sudah terdaftar");
            } else {
                Statement perintah=Koneksidb.createStatement();
                perintah.execute(sqlsimpan);
                JOptionPane.showMessageDialog(null, "Data Kategori Berita berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }

    public void simpanKategoriBerita02(String id_kategori, String nama_kategori, String keterangan){
        try {
            String sqlsimpan="INSERT INTO kategori_berita (id_kategori, nama_kategori, keterangan) VALUES (?, ?, ?)";
            String sqlcari= "SELECT*FROM kategori_berita WHERE id_kategori = ?";
            
            PreparedStatement cari = Koneksidb.prepareStatement(sqlcari);
            cari.setString(1, id_kategori);
            ResultSet data = cari.executeQuery();
            
            if (data.next()){
                JOptionPane.showMessageDialog(null, "ID Kategori sudah terdaftar");
                this.duplikasi = true;
                this.CEK_NAMA_KATEGORI_KB = data.getString("nama_kategori");
                this.CEK_KETERANGAN_KB = data.getString("keterangan");
            } else {
                this.duplikasi = false;
                this.CEK_NAMA_KATEGORI_KB = null;
                this.CEK_KETERANGAN_KB = null;
                
                PreparedStatement perintah = Koneksidb.prepareStatement(sqlsimpan);
                perintah.setString(1, id_kategori);
                perintah.setString(2, nama_kategori);
                perintah.setString(3, keterangan);
                perintah.executeUpdate();
                JOptionPane.showMessageDialog(null, "Data Kategori Berita berhasil disimpan");
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void ubahKategoriBerita(String id_kategori, String nama_kategori, String keterangan){
        try {
            String sqlubah="UPDATE kategori_berita SET nama_kategori = ?, keterangan = ? WHERE id_kategori = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlubah);
            perintah.setString(1, nama_kategori);
            perintah.setString(2, keterangan);
            perintah.setString(3, id_kategori); 
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Kategori Berita berhasil diubah");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void hapusKategoriBerita(String id_kategori){
        try {
            String sqlhapus="DELETE FROM kategori_berita WHERE id_kategori = ?";
            PreparedStatement perintah = Koneksidb.prepareStatement(sqlhapus);
            perintah.setString(1, id_kategori);
            perintah.executeUpdate();
            JOptionPane.showMessageDialog(null, "Data Kategori Berita berhasil dihapus");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
    
    public void tampilDataKategoriBerita(JTable komponentabel, String SQL){
        try {
            PreparedStatement perintah = Koneksidb.prepareStatement(SQL);
            ResultSet data = perintah.executeQuery();
            ResultSetMetaData meta = data.getMetaData();
            int jumlahkolom = meta.getColumnCount();
            DefaultTableModel modeltabel = new DefaultTableModel();
            
            modeltabel.addColumn("ID Kategori");
            modeltabel.addColumn("Nama Kategori");
            modeltabel.addColumn("Keterangan");
            
            while(data.next()){
                Object[] row = new Object[jumlahkolom];
                for(int i=1; i<=jumlahkolom; i++){
                    row[i-1]=data.getObject(i);
                }
                modeltabel.addRow(row);
            }
            komponentabel.setModel(modeltabel);
        } catch (Exception e) {
        }
    }
}
    
